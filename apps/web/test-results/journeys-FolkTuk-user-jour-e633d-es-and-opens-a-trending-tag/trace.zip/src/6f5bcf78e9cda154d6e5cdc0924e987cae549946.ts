import { test, expect, type Page } from '@playwright/test';

const user = {
  id: 'u1',
  email: 'alex@example.com',
  createdAt: new Date().toISOString(),
  profile: { username: 'alex', displayName: 'Alex', bio: 'Hello', avatarUrl: null, bannerUrl: null },
};

function mockApi(page: Page) {
  return page.route('**/identity/login', async (route) => {
    await route.fulfill({ json: { accessToken: 'test-token', user } });
  });
}

test.describe('FolkTuk user journeys', () => {
  test.beforeEach(async ({ page }) => {
    await page.route('**/identity/me', async (route) => route.fulfill({ json: user }));
    await page.route('**/posts?*', async (route) => route.fulfill({ json: { data: [], total: 0, page: 1, limit: 10 } }));
    await page.route('**/posts/trending', async (route) => route.fulfill({ json: [{ topic: '#folk', count: 3 }] }));
    await page.route('**/tags/trending', async (route) => route.fulfill({ json: [{ tag: '#folk', count: 3 }] }));
    await page.route('**/communities/joined', async (route) => route.fulfill({ json: [] }));
  });

  test('logs in and stores the JWT token', async ({ page }) => {
    await mockApi(page);
    await page.goto('/login');
    await page.getByLabel(/email/i).fill(user.email);
    await page.getByLabel(/password/i).fill('Password123!');
    await page.getByRole('button', { name: /log in/i }).click();
    await expect.poll(() => page.evaluate(() => localStorage.getItem('folktuk_token'))).toBe('test-token');
  });

  test('searches and opens a trending tag', async ({ page }) => {
    await page.route('**/search?*', async (route) => route.fulfill({ json: { query: '#folk', type: 'tags', posts: [], communities: [], users: [], tags: [{ tag: '#folk', count: 3 }] } }));
    await page.goto('/search?q=%23folk');
    await expect(page.getByText('#folk')).toBeVisible();
    await page.getByText('#folk').first().click();
  });

  test('opens profile editing and submits display name and bio', async ({ page }) => {
    await page.route('**/users/u1?*', async (route) => route.fulfill({ json: { ...user, posts: { data: [], total: 0, page: 1, limit: 10 } } }));
    await page.route('**/users/me', async (route) => route.fulfill({ json: { ...user, profile: { ...user.profile, displayName: 'Updated Alex', bio: 'Updated bio' } } }));
    await page.goto('/profile/u1');
    await page.getByRole('button', { name: /edit profile/i }).click();
    await page.getByLabel(/display name/i).fill('Updated Alex');
    await page.getByLabel(/^bio$/i).fill('Updated bio');
    await page.getByRole('button', { name: /save changes/i }).click();
    await expect(page.getByText('Updated Alex')).toBeVisible();
    await expect(page.getByText('Updated bio')).toBeVisible();
  });
});
